# Dual-Brain Quant Engine Website

Open `index.html` in a modern browser.

This is a browser-based frontend conversion of the uploaded Streamlit dashboard. It preserves the dashboard layout and paper-trading interactions, but the browser version uses simulated market data and does not connect to Binance, Gemini, Claude, or the original SQLite database.

For live API/database functionality, the original Python/Streamlit application remains the appropriate backend starting point.
